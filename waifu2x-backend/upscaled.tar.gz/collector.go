package main

import (
	"fmt"
	"net/http"
	"strconv"
)

// A buffered channel that we can send work requests on.
var WorkQueue = make(chan FileStruct, 100)

func Collector(w http.ResponseWriter, r *http.Request) {
	// Make sure we can only be called with an HTTP POST request.
	if r.Method != "POST" {
		w.Header().Set("Allow", "POST")
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}

	fileId, err := uploadFile(w, r)

	if err != nil {
		fmt.Println("Upload err", err)
		return
	}

	// File name

	_, handler, _ := r.FormFile("imageFile")

	// Now, we retrieve the person's name from the request.
	ScaleFactor, _ := strconv.Atoi(r.FormValue("scale"))
	NoiseFactor, _ := strconv.Atoi(r.FormValue("noise"))

	// Now, we take the delay, and the person's name, and make a WorkRequest out of them.
	work := FileStruct{
		Response:    w,
		UUID:        fileId,
		FileName:    handler.Filename,
		ScaleFactor: ScaleFactor,
		NoiseFactor: NoiseFactor,
	}

	// Push the work onto the queue.
	WorkQueue <- work
	fmt.Println("Work request queued")
}
