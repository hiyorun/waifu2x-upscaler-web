// package main

// import (
// 	"fmt"
// 	"net/http"
// )

// func main() {
// 	fmt.Println("Upscale server activated")
// 	setupRoutes()
// }

// func setupRoutes() {
// 	http.HandleFunc("/upload", uploadFile)
// 	http.ListenAndServe(":5173", nil)
// }

package main

import (
	"flag"
	"fmt"
	"net/http"
)

var (
	NWorkers = flag.Int("n", 4, "The number of workers to start")
)

func main() {
	// Parse the command-line flags.
	flag.Parse()

	// Start the dispatcher.
	fmt.Println("Starting the dispatcher")
	StartDispatcher(*NWorkers)

	// Register our collector as an HTTP handler function.
	fmt.Println("Registering the collector")
	http.HandleFunc("/upscale", Collector)

	// Start the HTTP server!
	fmt.Println("HTTP server listening on 5173")
	if err := http.ListenAndServe(":5173", nil); err != nil {
		fmt.Println(err.Error())
	}
}
