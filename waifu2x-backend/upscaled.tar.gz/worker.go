package main

import (
	"fmt"
	"log"
	"os"
)

type Worker struct {
	ID          int
	Work        chan FileStruct
	WorkerQueue chan chan FileStruct
	QuitChan    chan bool
}

// NewWorker creates, and returns a new Worker object. Its only argument
// is a channel that the worker can add itself to whenever it is done its
// work.
func NewWorker(id int, workerQueue chan chan FileStruct) Worker {
	// Create, and return the worker.
	worker := Worker{
		ID:          id,
		Work:        make(chan FileStruct),
		WorkerQueue: workerQueue,
		QuitChan:    make(chan bool)}

	return worker
}

// This function "starts" the worker by starting a goroutine, that is
// an infinite "for-select" loop.
func (w *Worker) Start() {
	go func() {
		for {
			// Add ourselves into the worker queue.
			w.WorkerQueue <- w.Work

			select {
			case work := <-w.Work:
				// Receive a work request.
				fmt.Printf("worker%d: upscaling, %s\n", w.ID, work.FileName)
				filename, err := startUpscale(work.UUID, work.FileName, work.NoiseFactor, work.ScaleFactor)
				if err != nil {
					log.Println(err)
					return
				}
				work.Response.Header().Set("Content-Disposition", "attachment; filename="+filename)
				returnFile, err := os.ReadFile("./upscaled-images/filename")
				if err != nil {
					log.Println(err)
					return
				}
				work.Response.Write(returnFile)

			case <-w.QuitChan:
				// We have been asked to stop.
				fmt.Printf("worker%d stopping\n", w.ID)
				return
			}
		}
	}()
}

// Stop tells the worker to stop listening for work requests.
//
// Note that the worker will only stop *after* it has finished its work.
func (w *Worker) Stop() {
	go func() {
		w.QuitChan <- true
	}()
}
