package main

import (
	"net/http"
	"time"

	"github.com/google/uuid"
)

type WorkRequest struct {
	Name  string
	Delay time.Duration
}

type FileStruct struct {
	Response    http.ResponseWriter
	UUID        uuid.UUID
	FileName    string
	ScaleFactor int
	NoiseFactor int
}
